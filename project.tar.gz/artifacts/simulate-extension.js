(() => {
  const observer = new MutationObserver(() => {
    if (document.body) {
      document.body.setAttribute('cz-shortcut-listen', 'true');
      observer.disconnect();
    }
  });
  observer.observe(document, { childList: true, subtree: true });
})();