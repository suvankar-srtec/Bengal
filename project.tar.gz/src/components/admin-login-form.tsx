"use client";

import { useState, type FormEvent } from "react";
import { useRouter } from "next/navigation";
import { PasswordInput } from "./password-input";

export function AdminLoginForm() {
  const router = useRouter();
  const [username, setUsername] = useState("");
  const [password, setPassword] = useState("");
  const [error, setError] = useState("");
  const [busy, setBusy] = useState(false);

  async function submit(event: FormEvent<HTMLFormElement>) {
    event.preventDefault();
    if (busy) return;
    setBusy(true);
    setError("");

    try {
      const response = await fetch("/api/auth/login", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ username, password }),
      });
      const result = await response.json();
      if (!response.ok) throw new Error(result.error || "Login failed.");
      router.replace("/dashboard");
    } catch (error) {
      setError(error instanceof Error ? error.message : "Login failed.");
    } finally {
      setBusy(false);
    }
  }

  return <form className="admin-login-form" onSubmit={submit}>
    <div className="admin-login-field">
      <label htmlFor="admin-username">User ID</label>
      <input id="admin-username" autoComplete="username" value={username} onChange={(event) => setUsername(event.target.value)} placeholder="Enter User ID" required autoFocus />
    </div>
    <div className="admin-login-field">
      <label htmlFor="admin-password">Password</label>
      <PasswordInput id="admin-password" autoComplete="current-password" value={password} onChange={(event) => setPassword(event.target.value)} placeholder="Enter password" required />
    </div>
    {error && <div className="admin-login-error" role="alert">{error}</div>}
    <button className="admin-login-button" type="submit" disabled={busy}>
      {busy ? <><span className="admin-login-spinner" /> Signing in…</> : "Sign in"}
    </button>
  </form>;
}
