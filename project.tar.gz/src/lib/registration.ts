import { z } from "zod";

export const EVENT = {
  id: "aalap-alochona-2026-09-29",
  name: "Aalap Alochona",
  date: "2026-09-29",
} as const;

// Store and calculate money in paise, never floating-point rupees.
export type MealChoice = "snacks" | "lunch" | "dinner";

export type ParticipationPrices = {
  participation: number;
  standee: number;
  presentation: number;
  includedMeals: MealChoice[];

  // Legacy meal fields are kept so older data and screens remain readable.
  // New registrations never charge separately for meals.
  mealOption: MealChoice;
  snacks: number;
  lunch: number;
  dinner: number;
};

export const PRICES: ParticipationPrices = {
  participation: 118000,
  standee: 295000,
  presentation: 3540000,
  includedMeals: ["lunch"],
  mealOption: "lunch",
  snacks: 0,
  lunch: 0,
  dinner: 0,
};

export function mealPriceForChoice(prices: ParticipationPrices, choice: MealChoice) {
  return prices[choice];
}

export function mealChoiceLabel(choice: MealChoice) {
  return choice === "snacks" ? "Snacks" : choice === "lunch" ? "Lunch" : "Dinner";
}

export function mealChoicesLabel(choices: readonly MealChoice[]) {
  return choices.length ? choices.map(mealChoiceLabel).join(", ") : "No meals";
}

export function participationPricesFromRow(row: Record<string, unknown> | undefined): ParticipationPrices {
  const read = (value: unknown, fallback: number) => {
    const number = Number(value);
    return Number.isInteger(number) && number >= 0 ? number : fallback;
  };

  const mealOption = row?.meal_option === "snacks" || row?.meal_option === "dinner"
    ? row.meal_option
    : "lunch";

  const rawIncludedMeals = row?.included_meals;
  const includedMeals: MealChoice[] = Array.isArray(rawIncludedMeals)
    ? Array.from(new Set(rawIncludedMeals.filter(
        (value): value is MealChoice => value === "snacks" || value === "lunch" || value === "dinner",
      )))
    : [mealOption];

  return {
    participation: read(row?.participation_unit_paise, PRICES.participation),
    standee: read(row?.standee_unit_paise, PRICES.standee),
    presentation: read(row?.presentation_unit_paise, PRICES.presentation),
    includedMeals,
    mealOption,
    snacks: read(row?.snacks_unit_paise, PRICES.snacks),
    lunch: read(row?.lunch_unit_paise, PRICES.lunch),
    dinner: read(row?.dinner_unit_paise, PRICES.dinner),
  };
}

export const LIMITS = { participation: 20, standee: 10 } as const;

export const registrationSchema = z.object({
  submissionId: z.uuid(),
  eventContentId: z.number().int().positive().nullable().default(null),
  memberName: z.string().trim().min(2, "Enter your full name.").max(120, "Use 120 characters or fewer."),
  email: z.email("Enter a valid email address.").max(254).transform((email) => email.toLowerCase()),
  phone: z.string().regex(/^[6-9]\d{9}$/, "Enter a valid 10-digit Indian WhatsApp number."),
  billingDetails: z.string().trim().toUpperCase().regex(
    /^(?:[A-Z]{5}[0-9]{4}[A-Z]|[0-9]{2}[A-Z]{5}[0-9]{4}[A-Z][A-Z0-9]Z[A-Z0-9])$/,
    "Enter a valid 10-character PAN or 15-character GSTIN.",
  ),
  photoDataUrl: z.string()
    .max(220000, "Photo is too large.")
    .regex(/^data:image\/(?:jpeg|png|webp);base64,/, "Choose a valid JPG, PNG or WebP photo.")
    .nullable()
    .default(null),
  participationQuantity: z.number().int().min(1).max(LIMITS.participation),
  standeeQuantity: z.number().int().min(0).max(LIMITS.standee),
  // Kept for compatibility with already-open forms. New forms do not expose meal selection.
  mealChoice: z.enum(["snacks", "lunch", "dinner"]).nullable().default(null),
  presentationSelected: z.boolean(),
  additionalParticipantNames: z.array(
    z.string().trim().min(2, "Enter the participant’s full name.").max(120, "Use 120 characters or fewer."),
  ).max(LIMITS.participation - 1).default([]),
}).superRefine((data, context) => {
  if (data.additionalParticipantNames.length !== data.participationQuantity - 1) {
    context.addIssue({ code: "custom", path: ["additionalParticipantNames"], message: "Provide one name for every participant selected." });
  }
});

export type RegistrationInput = z.infer<typeof registrationSchema>;
export type RegistrationFieldKey = keyof RegistrationInput | `participantName${number}`;
export type FieldErrors = Partial<Record<RegistrationFieldKey, string>>;

export function registrationFieldKey(path: readonly PropertyKey[]): RegistrationFieldKey {
  return path[0] === "additionalParticipantNames"
    ? `participantName${typeof path[1] === "number" ? path[1] + 2 : 2}`
    : String(path[0]) as RegistrationFieldKey;
}
export type RegistrationReceipt = {
  id: string;
  reference: string;
  totalPaise: number;
  paymentStatus: "unpaid" | "paid" | "refunded";
};

export function calculateTotal(
  input: Pick<RegistrationInput, "participationQuantity" | "standeeQuantity" | "presentationSelected">,
  prices: ParticipationPrices = PRICES,
) {
  return input.participationQuantity * prices.participation
    + input.standeeQuantity * prices.standee
    + (input.presentationSelected ? prices.presentation : 0);
}

export function formatMoney(paise: number) {
  return new Intl.NumberFormat("en-IN", {
    style: "currency", currency: "INR", minimumFractionDigits: 2,
  }).format(paise / 100);
}
